## General Workflow

![Celery process flow](images/flow.png)

## WebSockets and Celery Workflow

![WebSockets and Celery Workflow](images/websockets_flow.png)

## Deployment Workflow

![Deployment Workflow](images/deployment_flow.png)
